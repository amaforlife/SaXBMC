<h1>Surveillance Cameras</h1>

This addon shows the streams of maximum three surveillance cameras. For this, the URLs of the cams must be entered in the setup. If no stream URLs are entered, a corresponding notification message is issued. 

Dieses Addon zeigt die Streams von maximal 3 Überwachungskameras. Dazu müssen die entsprechenden URLs der Cams im Setup eingetragen werden. Sind keine Stream-URLs eingetragen, erfolgt eine entsprechende Hinweismeldung.