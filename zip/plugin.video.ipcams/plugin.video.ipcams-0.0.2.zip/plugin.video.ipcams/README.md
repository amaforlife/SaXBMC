<h1>Surveillance Cameras</h1>

Dieses Addon zeigt die Streams von maximal 3 Überwachungskameras. Dazu müssen die entsprechenden URLs der Cams im Setup eingetragen werden. Sind keine Stream-URLs eigetragen, erfolgt eine entsprechende Hinweismeldung.