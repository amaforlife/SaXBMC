# SPDX-License-Identifier: GPL-2.0-or-later
# Copyright (C) 2017-present Team LibreELEC (https://libreelec.tv)

import os
import stat
import subprocess

import threading
import xbmc
import xbmcaddon
import xbmcgui

from resources.lib.artistinfo import *

FIFO = '/var/run/librespot'
ITEM = 'rtp://127.0.0.1:6666'
SINK = 'librespot_sink'

ID = xbmcaddon.Addon().getAddonInfo('id')
ICON = xbmcaddon.Addon().getAddonInfo('icon')
LISTITEM = xbmcgui.ListItem()
LISTITEM.addStreamInfo('audio', {'codec': 'pcm'})
LISTITEM.setArt({'thumb': ICON})
LISTITEM.setPath(ITEM)


def log(message):
    xbmc.log('Librespot: {}'.format(message), xbmc.LOGNOTICE)


def pactl(bit):
    log('pactl suspend-sink {} {}'.format(SINK, bit))
    subprocess.call(['pactl', 'suspend-sink', SINK, bit])


def systemctl(command):
    log('systemctl {} {}'.format(command, ID))
    return subprocess.call(['systemctl', command, ID])


class Controller(threading.Thread):

    def __init__(self, player):
        super(Controller, self).__init__()
        self.player = player

    def run(self):
        log('controller started')
        try:
            os.unlink(FIFO)
        except OSError:
            pass
        os.mkfifo(FIFO)
        while (os.path.exists(FIFO) and
               stat.S_ISFIFO(os.stat(FIFO).st_mode)):
            with open(FIFO, 'r') as fifo:
                command = fifo.read().splitlines()
                log('controller received {}'.format(str(command)))
                if len(command) == 0:
                    break
                elif command[0] == 'play':
                    self.player.play(command[1:])
                elif command[0] == 'stop':
                    self.player.stop()
                elif command[0] == 'pause':
                    self.player.pause()
        try:
            os.unlink(FIFO)
        except OSError:
            pass
        log('controller stopped')

    def stop(self):
        with open(FIFO, 'w') as fifo:
            fifo.close()
        self.join()


class Librespot():

    def __init__(self):
        self.isStarted = systemctl('is-started')

    def restart(self):
        log('librespot restart')
        self.isStarted = 0
        pactl('1')
        systemctl('restart')

    def stop(self):
        log('librespot stop')
        if self.isStarted == 0:
            self.isStarted = 1
            pactl('1')
            systemctl('stop')


class Monitor(xbmc.Monitor):

    def __init__(self, player):
        super(Monitor, self).__init__(self)
        self.player = player

    def onSettingsChanged(self):
        log('settings changed')
        self.player.restart()


class Player(xbmc.Player):

    def __init__(self):
        super(Player, self).__init__(self)
        self.librespot = Librespot()
        self.wrapper = TheAudioDbWrapper()
        if self.isPlaying():
            self.onPlayBackStarted()

    def onPlayBackEnded(self):
        log('a playback ended')
        self.librespot.restart()

    def onPlayBackStarted(self):
        log('a playback started')
        if self.getPlayingFile() != ITEM:
            self.librespot.stop()

    def onPlayBackStopped(self):
        log('a playback stopped')
        self.librespot.restart()

    def play(self, info):
        self.wrapper.clearAttr()
        self.wrapper.artistname = info[0]
        self.wrapper.albumname = info[2]
        artist_artwork = self.wrapper.getArtistArtwork()
        album_artwork = self.wrapper.getAlbumArtwork()

        if xbmcaddon.Addon().getSetting('ls_m') == 'Kodi':
            LISTITEM.setInfo('music',
                             {'artist': info[0],
                              'title': info[1],
                              'album': info[2]})
            LISTITEM.setArt({'thumb': ICON})
            p_icon = ICON

            if xbmcaddon.Addon().getSetting('ls_a') == 'true':
                if album_artwork:
                    p_icon = album_artwork['thumb']
                    LISTITEM.setArt({'thumb': album_artwork['thumb'],
                                      'cdart': album_artwork['CDart']})
                else:
                    log('no album artwork available for {}'.format(info[2]))
                if artist_artwork:
                    LISTITEM.setArt({'fanart': artist_artwork['fanart'],
                                      'banner': artist_artwork['banner'],
                                      'clearart': artist_artwork['clearart']})
                else:
                    log('no artist artwork available for {}'.format(info[0]))

            if self.isPlaying():
                self.updateInfoTag(LISTITEM)
                log('player updated librespot playback')
            else:
                pactl('0')
                super(Player, self).play(ITEM, LISTITEM)
                xbmcgui.Window(12006).show()
                log('player started librespot playback')

        dialog = xbmcgui.Dialog()
        dialog.notification(info[1], info[0], icon=p_icon, sound=False)
        del dialog

    def pause(self):
        if self.isPlaying() and self.getPlayingFile() == ITEM:
            super(Player, self).pause()
            log('player paused librespot playback')

    def restart(self):
        if self.isPlaying() and self.getPlayingFile() == ITEM:
            self.stop()
        else:
            self.librespot.restart()

    def stop(self):
        if self.isPlaying() and self.getPlayingFile() == ITEM:
            super(Player, self).stop()
            log('player stopped librespot playback')


if __name__ == '__main__':
    log('monitor started')
    player = Player()
    controller = Controller(player)
    controller.start()
    Monitor(player).waitForAbort()
    controller.stop()
    log('monitor ended')
