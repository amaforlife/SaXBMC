# SPDX-License-Identifier: GPL-2.0-or-later
# Copyright (C) 2017-present Team LibreELEC (https://libreelec.tv)

import os
import stat
import subprocess
import threading
import xbmcgui

from lib.toollib import *

Tools = KodiLib()

PORT = '6666'
SINK = 'librespot_sink'


def suspendSink(bit):
    subprocess.call(['pactl', 'suspend-sink', SINK, bit])
    Tools.writeLog('pactl suspend-sink %s %s called' % (SINK, bit))


def systemctl(command):
    subprocess.call(['systemctl', command, ADDON.getAddonInfo('id')])
    Tools.writeLog('systemctl %s %s called' % (command, ADDON.getAddonInfo('id')))


class Controller(threading.Thread):
    FIFO = '/var/run/librespot'

    def __init__(self, player):
        super(Controller, self).__init__()
        self.player = player

    def run(self):
        try:
            os.unlink(self.FIFO)
        except OSError, e:
            Tools.writeLog('could not unlink %s' % (self.FIFO), xbmc.LOGERROR)
            if e.message: Tools.writeLog(e.message, xbmc.LOGERROR)

        os.mkfifo(self.FIFO)
        while os.path.exists(self.FIFO) and stat.S_ISFIFO(os.stat(self.FIFO).st_mode):
            with open(self.FIFO, 'r') as fifo:
                command = fifo.read().splitlines()
                for line in xrange(0, len(command)): Tools.writeLog(command[line])
                if len(command) == 0:
                    break
                elif command[0] == 'play' and len(command) == 3:
                    dialog = xbmcgui.Dialog()
                    dialog.notification(command[1],
                                        command[2],
                                        icon=ADDON.getAddonInfo('icon'),
                                        sound=False)
                    del dialog

                    self.player.play()
                    self.player.update(artist=command[1], title=command[2])

                elif command[0] == 'stop':
                    self.player.stop()
                elif command[0] == 'pause':
                    self.player.pause()
        try:
            os.unlink(self.FIFO)
        except OSError, e:
            Tools.writeLog('could not unlink %s' % (self.FIFO), xbmc.LOGERROR)
            if e.message: Tools.writeLog(e.message, xbmc.LOGERROR)

    def stop(self):
        with open(self.FIFO, 'w') as fifo:
            fifo.close()


class Player(xbmc.Player):
    ITEM = 'rtp://127.0.0.1:%s' % (PORT)

    def __init__(self):
        super(Player, self).__init__(self)

        self.listitem = xbmcgui.ListItem(path=self.ITEM)
        self.listitem.addStreamInfo('audio', {'codec': 'mp3'})
        self.listitem.setArt({'thumb': ADDON.getAddonInfo('icon')})

        if self.isPlaying():
            self.onPlayBackStarted()

    def onPlayBackEnded(self):
        suspendSink('1')
        xbmc.sleep(1000)
        if not self.isPlaying():
            systemctl('restart')

    def onPlayBackStarted(self):
        if self.getPlayingFile() != self.ITEM:
            suspendSink('1')
            systemctl('stop')

    def onPlayBackStopped(self):
        systemctl('restart')

    def play(self):
        if not self.isPlaying() and Tools.getAddonSetting('output') == 'Kodi':
            suspendSink('0')
            super(Player, self).play(self.ITEM, listitem=self.listitem)
            xbmcgui.Window(12006).show()

    def update(self, artist='', title=''):
        #
        # https://codedocs.xyz/AlwinEsch/kodi/group__python___player.html#ga0389794dc46f9447ee480d17814eb2ed
        #
        if self.isPlaying() and Tools.getAddonSetting('output') == 'Kodi':
            self.listitem.setInfo('music', {'title': title, 'artist': artist})
            super(Player, self).updateInfoTag(self.listitem)
            if artist and title:
                Tools.writeLog('Labels updated - artist: %s, title: %s' % (artist, title))
            else:
                Tools.writeLog('Labels cleared')

    def pause(self):
        if self.isPlaying() and self.getPlayingFile() == self.ITEM:
            super(Player, self).pause()

    def stop(self):
        suspendSink('1')
        if self.isPlaying() and self.getPlayingFile() == self.ITEM:
            self.update()
            super(Player, self).stop()
        else:
            systemctl('restart')


class Monitor(xbmc.Monitor):

    def __init__(self, player):
        super(Monitor, self).__init__(self)
        self.player = player

    def onSettingsChanged(self):
        self.player.stop()


if __name__ == '__main__':
    player = Player()
    controller = Controller(player)
    controller.start()
    Monitor(player).waitForAbort()
    controller.stop()
    controller.join()
