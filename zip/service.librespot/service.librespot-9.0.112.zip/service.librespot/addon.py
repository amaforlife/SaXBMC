# SPDX-License-Identifier: GPL-2.0-or-later
# Copyright (C) 2017-present Team LibreELEC (https://libreelec.tv)

import alsaaudio as alsa
import xbmcgui

from lib.toollib import *

dialog = xbmcgui.Dialog()
strings = ADDON.getLocalizedString
devices = alsa.pcms()[1:]
if len(devices) == 0:
    dialog.ok(ADDON.getAddonInfo('name'), strings(30210))
else:
    idx = dialog.select(strings(30115), devices)
    if idx > -1:
        ADDON.setSetting('device', devices[idx])
del dialog
