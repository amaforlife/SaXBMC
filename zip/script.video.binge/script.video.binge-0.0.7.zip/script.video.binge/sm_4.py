from handler import ContextHandler as ch

if __name__ == '__main__':
    ch().clear_all()