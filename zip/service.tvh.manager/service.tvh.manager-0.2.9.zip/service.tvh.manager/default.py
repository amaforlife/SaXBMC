# -*- coding: utf-8 -*-
import sys, os, platform, subprocess, traceback
import socket
import re
import random
import xbmc, xbmcaddon, xbmcgui
import time, datetime
import urllib2
from xml.dom import minidom
import smtplib
from email.message import Message

# global

__addon__ = xbmcaddon.Addon()
__addonname__ = __addon__.getAddonInfo('id')
__path__ = __addon__.getAddonInfo('path')
__version__ = __addon__.getAddonInfo('version')
__LS__ = __addon__.getLocalizedString

__IconStop__ = xbmc.translatePath(os.path.join(__path__, 'resources', 'media', 'stop.png'))
__IconError__ = xbmc.translatePath(os.path.join(__path__, 'resources', 'media', 'error.png'))
__IconSchedule__ = xbmc.translatePath(os.path.join(__path__, 'resources', 'media', 'schedule.png'))

__datapath__ = xbmc.translatePath(os.path.join('special://temp/', __addonname__))
if not os.path.exists(__datapath__): os.makedirs(__datapath__)

SHUTDOWN_CMD = xbmc.translatePath(os.path.join(__path__, 'resources', 'lib', 'shutdown.sh'))
EXTGRABBER = xbmc.translatePath(os.path.join(__path__, 'resources', 'lib', 'epggrab_ext.sh'))

CYCLE = 15  # polling cycle
TVHPORT = ':9981/status.xml'

PLATFORM_OE = True if ('OPENELEC' in ', '.join(platform.uname()).upper()) else False
HOST = socket.gethostname()
PIDFILE = os.path.join(__datapath__, __addonname__ + '.pid')
LOGFILE = os.path.join(__datapath__, __addonname__ + '.log')

OSD = xbmcgui.Dialog()

# binary Flags

isPWR = 0b10000
isNET = 0b01000
isPRG = 0b00100
isREC = 0b00010
isEPG = 0b00001
isUSR = 0b00000


def getProcessPID(process):
    _syscmd = subprocess.Popen(['pidof', process], stdout=subprocess.PIPE)
    PID = _syscmd.stdout.read().strip()
    return PID if PID > 0 else False


# check for PIDFILE, if no PIDFILE available, user or system has
# powered on the system at first time (pf = false)

def isPIDFile(makePIDFile=True):
    pf = False
    pidofXBMC = str(getProcessPID('xbmc.bin'))
    # KODI
    if not pidofXBMC: pidofXBMC = str(getProcessPID('kodi.bin'))
    if not os.path.isfile(PIDFILE):
        if makePIDFile:
            __f = open(PIDFILE, 'w')
            __f.write(pidofXBMC + '\n')
            __f.close()
    else:
        __f = open(PIDFILE, 'r')
        pidofFile = __f.readline().strip()
        __f.close()
        if pidofFile == pidofXBMC:
            pf = True
        elif makePIDFile:
            __f = open(PIDFILE, 'w')
            __f.write(pidofXBMC + '\n')
            __f.close()
    return pf

### MAIN CLASS

class Manager(object):
    def __init__(self):

        self.__conn_established = None
        self.__xml = None
        self.__bState = None
        self.__message = None
        self.__msgcount = None
        self.__recTitles = []
        self.__bBtnPwr = None
        self.__bBtnElse = None
        self.__rndProcNum = random.randint(1, 1024)
        self.__wakeUp = None
        self.__wakeUpUT = None
        self.__wakeUpStrOffset = None
        self.__wakeUpMessage = ''
        self.__excluded_ports = ''
        self.__ScreensaverActive = None
        self.__windowID = None

        self.getSettings()
        self.establishConn()

    ### read addon settings

    def getSettings(self):
        self.__prerun = int(re.match('\d+', __addon__.getSetting('margin_start')).group())
        self.__postrun = int(re.match('\d+', __addon__.getSetting('margin_stop')).group())
        self.__wakeup = __addon__.getSetting('wakeup_method')
        self.__shutdown = int(__addon__.getSetting('shutdown_method'))
        self.__counter = int(re.match('\d+', __addon__.getSetting('notification_counter')).group())
        self.__nextsched = True if __addon__.getSetting('next_schedule').upper() == 'TRUE' else False

        # TVHeadend server
        self.__server = __addon__.getSetting('TVH_URL')
        self.__user = __addon__.getSetting('TVH_USER')
        self.__pass = __addon__.getSetting('TVH_PASS')
        self.__maxattempts = int(__addon__.getSetting('conn_attempts'))

        # check for network activity
        self.__network = True if __addon__.getSetting('network').upper() == 'TRUE' else False

        # calculate exluded ports
        _np = __addon__.getSetting('excluded_ports')
        if _np:
            _np = _np.replace(',', ' ')
            _np = _np.join(' '.join(line.split()) for line in _np.splitlines())
            for line in _np.split(): self.__excluded_ports += (' | grep -v ":%s"' % (line))

        # check for post processors
        self.__pp_enabled = True if __addon__.getSetting('postprocessor_enable').upper() == 'TRUE' else False
        _pp = __addon__.getSetting('processor_list')

        # transform possible userinput from e.g. 'p1, p2,,   p3 p4  '
        # to a list like this: ['p1','p2','p3','p4']
        _pp = _pp.replace(',', ' ')
        _pp = _pp.join(' '.join(line.split()) for line in _pp.splitlines())
        self.__pp_list = _pp.split(' ')

        # mail settings
        self.__notification = True if __addon__.getSetting('smtp_sendmail').upper() == 'TRUE' else False
        self.__smtpserver = __addon__.getSetting('smtp_server')
        self.__smtpuser = __addon__.getSetting('smtp_user')
        self.__smtppass = __addon__.getSetting('smtp_passwd')
        self.__smtpenc = __addon__.getSetting('smtp_encryption')
        self.__smtpfrom = __addon__.getSetting('smtp_from')
        self.__smtpto = __addon__.getSetting('smtp_to')
        self.__charset = __addon__.getSetting('charset')

        # EPG-Wakeup settings
        self.__epg_interval = int(__addon__.getSetting('epgtimer_interval'))
        self.__epg_time = int(__addon__.getSetting('epgtimer_time'))
        self.__epg_duration = int(re.match('\d+', __addon__.getSetting('epgtimer_duration')).group())
        self.__epg_grab_ext = True if __addon__.getSetting('epg_grab_ext').upper() == 'TRUE' else False

    # Function to write a traceback report to logfile

    def traceError(self, err, exc_tb):
        while exc_tb:
            tb = traceback.format_tb(exc_tb)
            self.writeLog('%s' % err, xbmc.LOGERROR)
            self.writeLog('in module: %s' % (sys.argv[0].strip() or '<not defined>'), xbmc.LOGERROR)
            self.writeLog('at line:   %s' % traceback.tb_lineno(exc_tb), xbmc.LOGERROR)
            self.writeLog('in file:   %s' % tb[0].split(",")[0].strip()[6:-1],xbmc.LOGERROR)
            exc_tb = exc_tb.tb_next

    # Connect to TVHeadend and establish connection (log in))

    def establishConn(self):
        self.__conn_established = False
        while self.__maxattempts > 0:
            try:
                pwd_mgr = urllib2.HTTPPasswordMgrWithDefaultRealm()
                pwd_mgr.add_password(None, self.__server + TVHPORT, self.__user, self.__pass)
                handle = urllib2.HTTPBasicAuthHandler(pwd_mgr)
                opener = urllib2.build_opener(handle)
                opener.open(self.__server + TVHPORT)
                urllib2.install_opener(opener)
                self.__conn_established = True
                self.writeLog('Connection to %s established' % self.__server)
                break
            except Exception, e:
                self.traceError(e, sys.exc_traceback)
                self.__maxattempts -= 1
                self.writeLog('Remaining connection attempts to %s: %s' % (self.__server, self.__maxattempts))
                xbmc.sleep(5000)
                continue

        if not self.__conn_established:
            self.notifyOSD(__LS__(30030), __LS__(30031), __IconError__)
            xbmc.sleep(6000)

    # send email to user to inform about a successful completition

    def deliverMail(self, message):
        if self.__notification:
            try:
                __port = {'None': 25, 'SSL/TLS': 465, 'STARTTLS': 587}
                __s_msg = Message()
                __s_msg.set_charset(self.__charset)
                __s_msg.set_payload(message, charset=self.__charset)
                __s_msg["Subject"] = __LS__(30046) % (HOST)
                __s_msg["From"] = self.__smtpfrom
                __s_msg["To"] = self.__smtpto

                if self.__smtpenc == 'STARTTLS':
                    __s_conn = smtplib.SMTP(self.__smtpserver, __port[self.__smtpenc])
                    __s_conn.ehlo()
                    __s_conn.starttls()
                elif self.__smtpenc == 'SSL/TLS':
                    __s_conn = smtplib.SMTP_SSL(self.__smtpserver, __port[self.__smtpenc])
                    __s_conn.ehlo()
                else:
                    __s_conn = smtplib.SMTP(self.__smtpserver, __port[self.__smtpenc])
                __s_conn.login(self.__smtpuser, self.__smtppass)
                __s_conn.sendmail(self.__smtpfrom, self.__smtpto, __s_msg.as_string())
                __s_conn.close()
                self.writeLog('Mail delivered to %s.' % self.__smtpto)
                return True
            except Exception, e:
                self.traceError(e, sys.exc_traceback)
                self.writeLog('Mail could not be delivered. Check your settings.', xbmc.LOGERROR)
                return False
        else:
            self.writeLog('"%s" completed, no Mail delivered.' % message)
            return True

    def notifyOSD(self, header, message, icon=xbmcgui.NOTIFICATION_INFO):
        OSD.notification(header.encode('utf-8'), message.encode('utf-8'), icon)

    def dialogOK(self, header, message):
        OSD.ok(header.encode('utf-8'), message.encode('utf-8'))

    def writeLog(self, message, level=xbmc.LOGNOTICE):
        if self.__message == message:
            self.__msgcount += 1
            return
        else:
            if os.path.isfile(LOGFILE):
                __f = open(LOGFILE, 'a')
            else:
                __f = open(LOGFILE, 'w')
            if self.__msgcount > 0:
                __f.write('%s: >>> Last message repeated %s time(s)\n' % (
                    datetime.datetime.now().strftime('%d.%m.%Y %H:%M:%S'), self.__msgcount))
            self.__message = message
            self.__msgcount = 0
            __f.write('%s: %s\n' % (datetime.datetime.now().strftime('%d.%m.%Y %H:%M:%S'), message.encode('utf-8')))
            __f.close()
            xbmc.log('%s: %s' % (__addonname__, message.encode('utf-8')), level)

    def readXML(self, xmlnode):
        nodedata = []
        while self.__conn_established:
            try:
                __f = urllib2.urlopen(self.__server + TVHPORT)
                __xmlfile = __f.read()
                self.__xml = minidom.parseString(__xmlfile)
                __f.close()
                nodes = self.__xml.getElementsByTagName(xmlnode)
                if nodes:
                    for node in nodes:
                        nodedata.append(node.childNodes[0].data)
                break
            except Exception, e:
                self.traceError(e, sys.exc_traceback)
                self.writeLog("Could not read from %s" % self.__server, xbmc.LOGERROR)
                self.establishConn()
        return nodedata

    def getSysState(self, bNet=True):
        self.__bState = isUSR

        # Check for current recordings. If there a 'status' tag,
        # and content is "Recording" current recording is in progress
        nodedata = self.readXML('status')
        if nodedata and 'Recording' in nodedata: self.__bState |= isREC

        # Check for future recordings. If there is a 'next' tag,
        # then a future recording is happening
        nodedata = self.readXML('next')
        if nodedata and int(nodedata[0]) < (self.__prerun + self.__postrun) \
                or (self.__wakeup == "NVRAM" and int(nodedata[0]) < 11): self.__bState |= isREC

        # Check if system started up because of actualizing EPG-Data
        if self.__epg_interval > 0:
            __curTime = datetime.datetime.now()
            __dayDelta = self.__epg_interval
            if int(__curTime.strftime('%j')) % __dayDelta == 0: __dayDelta = 0
            __epgTime = (__curTime + datetime.timedelta(days=__dayDelta) -
                         datetime.timedelta(days=int(__curTime.strftime('%j')) % self.__epg_interval)).replace(hour=self.__epg_time, minute=0, second=0)
            if __epgTime < __curTime < __epgTime + datetime.timedelta(minutes=self.__epg_duration): self.__bState |= isEPG

        # Check if any postprocess is running
        if self.__pp_enabled:
            for proc in self.__pp_list:
                if getProcessPID(proc): self.__bState |= isPRG

        # Check for active network connection(s)
        if self.__network and bNet:
            nwc = subprocess.Popen('netstat -ano | grep ESTABLISHED | grep -v "127.0.0.1" | grep -v "off" %s' % self.__excluded_ports,
                                   stdout=subprocess.PIPE, shell=True).communicate()
            nwc = nwc[0].strip()
            if nwc and len(nwc.split("\n")) > 0: self.__bState |= isNET

        # Check if screensaver is running
        self.__ScScreensaverActive = xbmc.getCondVisibility('System.ScreenSaverActive')

    def calcNextSched(self):

        __WakeUpUTRec = 0
        __WakeUpUTEpg = 0
        __WakeEPG = 0
        __curTime = datetime.datetime.now()

        nodedata = self.readXML('next')
        if nodedata:
            self.__wakeUp = (__curTime + datetime.timedelta(minutes=int(nodedata[0]) - self.__prerun)).replace(second=0)
            __WakeUpUTRec = int(time.mktime(self.__wakeUp.timetuple()))
        else:
            self.writeLog('No recordings to schedule')

        if self.__epg_interval > 0:
            __dayDelta = self.__epg_interval
            if int(__curTime.strftime('%j')) % __dayDelta == 0: __dayDelta = 0
            __WakeEPG = (__curTime + datetime.timedelta(days=__dayDelta) -
                        datetime.timedelta(days=int(__curTime.strftime('%j')) % self.__epg_interval)).replace(hour=self.__epg_time, minute=0, second=0)
            if __curTime > __WakeEPG:
                __WakeEPG = __WakeEPG + datetime.timedelta(days=self.__epg_interval)

            __WakeUpUTEpg = int(time.mktime(__WakeEPG.timetuple()))

        if __WakeUpUTRec > 0 or __WakeUpUTEpg > 0:

            if __WakeUpUTRec <= __WakeUpUTEpg:
                if __WakeUpUTRec > 0:
                    self.__wakeUpUT = __WakeUpUTRec
                    self.__wakeUpStrOffset = 0
                elif __WakeUpUTEpg > 0:
                    self.__wakeUpUT = __WakeUpUTEpg
                    self.__wakeUp = __WakeEPG
                    self.__wakeUpStrOffset = 1
            elif __WakeUpUTRec > __WakeUpUTEpg:
                if __WakeUpUTEpg > 0:
                    self.__wakeUpUT = __WakeUpUTEpg
                    self.__wakeUp = __WakeEPG
                    self.__wakeUpStrOffset = 1
                elif __WakeUpUTRec > 0:
                    self.__wakeUpUT = __WakeUpUTRec
                    self.__wakeUpStrOffset = 0
            self.__wakeUpMessage = '\n%s %s' % (
                __LS__(30024), __LS__(30018 + self.__wakeUpStrOffset) % (self.__wakeUp.strftime('%d.%m.%Y %H:%M')))
            return True
        else:
            return False

    def setWakeup(self):

        if self.calcNextSched():
            __task = ['Recording', 'EPG-Update']
            self.writeLog('Wakeup for %s by %s at %s' % (__task[self.__wakeUpStrOffset], self.__wakeup,  self.__wakeUp.strftime('%d.%m.%y %H:%M')))
            if self.__nextsched:
                self.writeLog('Show notification about next schedule')
                self.notifyOSD(__LS__(30017), __LS__(30018 + self.__wakeUpStrOffset) % (self.__wakeUp.strftime('%d.%m.%Y %H:%M')), __IconSchedule__)
                xbmc.sleep(5000)

        _sm = ['Kodi/XBMC', 'OS']
        self.writeLog('Instruct the system to shut down using %s method' % _sm[self.__shutdown])

        if os.path.isfile(PIDFILE): os.remove(PIDFILE)
        if PLATFORM_OE:
            os.system('%s %s %s %s' % (SHUTDOWN_CMD, self.__wakeup, self.__wakeUpUT, self.__shutdown))
        else:
            os.system('sudo %s %s %s %s' % (SHUTDOWN_CMD, self.__wakeup, self.__wakeUpUT, self.__shutdown))
        if not self.__shutdown: xbmc.shutdown()

    ####################################### START MAIN SERVICE #####################################

    def start(self):
        self.writeLog('Starting service(%s)' % self.__rndProcNum)
        if isPIDFile(False):
            self.getSysState()
        else:
            self.getSysState(False)

        if self.__bState:
            if isPIDFile():
                self.__bBtnPwr = True
                self.writeLog('Powerbutton was pressed')
                if (self.__bState & isREC):
                    self.notifyOSD(__LS__(30015), __LS__(30020), __IconStop__)  # Notify 'Recording in progress'
                elif (self.__bState & isEPG):
                    self.notifyOSD(__LS__(30015), __LS__(30021), __IconStop__)  # Notify 'EPG-Update'
                elif (self.__bState & isPRG):
                    self.notifyOSD(__LS__(30015), __LS__(30022), __IconStop__)  # Notify 'Postprocessing'
                elif (self.__bState & isNET):
                    self.notifyOSD(__LS__(30015), __LS__(30023), __IconStop__)  # Notify 'Network active'
            else:
                if (self.__bState & isEPG) and self.__epg_grab_ext and os.path.isfile(EXTGRABBER):
                    self.writeLog('Starting script for grabbing external EPG')
                    #
                    # ToDo: implement startup of external script (epg grabbing)
                    #
                    try:
                        os.system(EXTGRABBER)
                    except Exception, e:
                        self.traceError(e, sys.exc_traceback)
                        self.writeLog('Could not start external EPG-Grabber', xbmc.LOGERROR)
                        
            self.__bBtnElse = False
            idle = xbmc.getGlobalIdleTime()

            ### START MAIN LOOP ###

            while (not xbmc.abortRequested and self.__bState and not self.__bBtnElse):

                time.sleep(CYCLE)
                idle += CYCLE
                xbmcIdle = xbmc.getGlobalIdleTime()

                if idle - xbmcIdle > CYCLE:
                    # Button pressed
                    self.__bBtnElse = True
                    self.writeLog('User activty detected')
                    break

                self.writeLog('Service polling Net/Post/Rec/EPG: {0:04b}'.format(self.__bState))

                # check outdated recordings
                nodedata = self.readXML('title')
                for item in nodedata:
                    if not item in self.__recTitles:
                        self.__recTitles.append(item)
                        self.writeLog('Recording of "%s" is/becomes active' % item)
                for item in self.__recTitles:
                    if not item in nodedata:
                        self.__recTitles.remove(item)
                        self.writeLog('Recording of "%s" has finished' % item)
                        if not self.__recTitles: self.calcNextSched()
                        if not self.__bBtnPwr:
                            self.deliverMail(__LS__(30047) % (HOST, item) + self.__wakeUpMessage)
                self.getSysState()
                if not self.__ScreensaverActive: self.__windowID = xbmcgui.getCurrentWindowId()

            ### END MAIN LOOP ###

            if not self.__bState and self.__bBtnPwr:
                self.writeLog('Display countdown dialog for %s secs' % self.__counter)
                __bar = 0
                __percent = 0
                __idleTime = xbmc.getGlobalIdleTime()
                __canceled = False

                # deactivate screensaver (if running), set progressbar and notify
                if self.__ScreensaverActive and self.__windowID: xbmc.executebuiltin('ActivateWindow(%s)') % self.__windowID
                pb = xbmcgui.DialogProgressBG()
                pb.create(__LS__(30010), __LS__(30011) % self.__counter)
                pb.update(__percent)

                # actualize progressbar
                while __bar < self.__counter:
                    __bar += 1
                    __percent = int(__bar * 100 / self.__counter)
                    pb.update(__percent, __LS__(30010), __LS__(30011) % (self.__counter - __bar))
                    if __idleTime > xbmc.getGlobalIdleTime():
                        __canceled = True
                        break
                    xbmc.sleep(1000)
                    __idleTime += 1
                pb.close()
                if not __canceled:
                    self.setWakeup()
                else:
                    self.writeLog('Countdown aborted by user')
            elif not self.__bState and not self.__bBtnPwr and not self.__bBtnElse:
                self.writeLog('Service(%s) was running without any user activity' % (self.__rndProcNum))
                self.setWakeup()
        else:
            if isPIDFile(): self.setWakeup()

        self.writeLog('Service(%s) finished' % (self.__rndProcNum))

        ##################################### END OF MAIN SERVICE #####################################


TVHMan = Manager()
try:
    if sys.argv[1] == 'checkmailsettings':
        setup_ok = TVHMan.deliverMail(__LS__(30065) % (HOST))
        if setup_ok:
            TVHMan.dialogOK(__LS__(30066), __LS__(30068) % (__addon__.getSetting('smtp_to')))
        else:
            TVHMan.dialogOK(__LS__(30067), __LS__(30069) % (__addon__.getSetting('smtp_to')))
except IndexError:
    TVHMan.start()

    __p = platform.uname()

    TVHMan.writeLog('<<<')
    TVHMan.writeLog('              _\|:|/_        BYE BYE')
    TVHMan.writeLog('               (o -)')
    TVHMan.writeLog('------------ooO-(_)-Ooo----- V.%s on %s --' % (__version__, __p[1]))
    TVHMan.writeLog('<<<\n')

del TVHMan
