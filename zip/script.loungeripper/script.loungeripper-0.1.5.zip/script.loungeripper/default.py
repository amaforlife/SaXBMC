# -*- coding: utf-8 -*-

import platform
import re
import subprocess
import sys
import traceback
import os
import glob
import datetime
import xbmc
import xbmcgui
import xbmcaddon

__addon__ = xbmcaddon.Addon()
__addonID__ = __addon__.getAddonInfo('id')
__addonname__ = __addon__.getAddonInfo('name')
__path__ = __addon__.getAddonInfo('path')
__version__ = __addon__.getAddonInfo('version')
__LS__ = __addon__.getLocalizedString
__IconOk__ = xbmc.translatePath(os.path.join(__path__, 'resources', 'media', 'disc.png'))
__IconError__ = xbmc.translatePath(os.path.join(__path__, 'resources', 'media', 'error.png'))

# PREDEFINES

# CPU Priority (Win): High, Normal, Low
CPU_W = ['start /wait /b /high ""', '', 'start /wait /b /low ""']

# CPU Priority (Linux): High, Normal, Low
CPU_L = ['nice -n -19', '', 'nice -n 19']

# max. Resolution: Full-HD, HDTV, SDTV (PAL), SDTV (NTSC)
MAXWIDTH = ['--maxWidth 1920', '--maxWidth 1280', '--maxWidth 720', '--maxWidth 640']

# Encoding quality: High, Normal, Low
QUALITY = ['-q 21', '-q 23', '-q 25']

# Greyscaling (Black&White Sources)
BW = '--greyscale'

# foreign audiotracks
ALLTRACKS = '-a 1,2,3,4,5,6,7,8,9,10'

# Converts filesizes to a human readable format (e.g. 123456 bytes to 123.4 KBytes)

def fmt_size(num, suffix='Bytes'):
    for unit in ['', 'K', 'M', 'G', 'T']:
        if abs(num) < 1024:
            return "%3.1f %s%s" % (num, unit, suffix)
        num /= 1024
    return "%.1f% s%s" % (num, 'T', suffix)

class LoungeRipper():

    class NoProfileEnabledException(Exception): pass
    class NoProfileSelectedException(Exception): pass
    class SystemSettingUndefinedException(Exception): pass
    class RemovableMediaNotPresentException(Exception): pass
    class MakemkvExitsNotProperlyException(Exception): pass
    class HandBrakeCLIExitsNotProperlyException(Exception): pass
    class RipEncodeProcessStatesToBGException(Exception): pass
    class AbortedRipCompletedException(Exception): pass
    class KillCurrentProcessCalledException(Exception): pass
    class CleanUpTempFolderException(Exception): pass
    class CouldNotFindValidFilesException(Exception): pass
    class UnexpectedGlobalError(Exception): pass

    def __init__(self):

        self.src = None
        self.destfolder = None
        self.extensions = ['*.mkv', '*.ts', '*.mp4', '*.mpg', '*.mpeg', '*.avi', '*.flv', '*.wmv', '*.264', '*.mov']
        self.task = None

        # Profile settings

        self.profile = None
        self.ripper = None
        self.encoder = None

        # Other

        self.ProgressBG = xbmcgui.DialogProgressBG()
        self.DialogOk = xbmcgui.Dialog()
        self.Monitor = xbmc.Monitor()

        self.getSystemSettings()

    def getSystemSettings(self):
        self.ripper_executable = __addon__.getSetting('makemkvcon')
        self.encoder_executable = __addon__.getSetting('HandBrakeCLI')
        self.logging = True if __addon__.getSetting('logging').upper() == "TRUE" else False
        self.tempfolder = __addon__.getSetting('tempfolder').rstrip('\\')
        self.basefolder = __addon__.getSetting('basefolder')
        self.subfolder = True if __addon__.getSetting('subfolder').upper() == 'TRUE' else False
        self.del_tf = True if __addon__.getSetting('deltempfolder').upper() == 'TRUE' else False

        self.nativelanguage = __addon__.getSetting('nativelanguage')
        # Parse the 3 letter language code from selection
        self.lang3 = re.search( r"(.*\()(.*)\)", self.nativelanguage).group(2)

        self.driveid = __addon__.getSetting('driveid')
        self.eject = True if __addon__.getSetting('eject').upper() == 'TRUE' else False

        self.chain_interrupted = True if __addon__.getSetting('chain_interrupted').upper() == 'TRUE' else False

    def getUserProfile(self):
        _profiles = []
        if self.getProcessPID(self.ripper_executable) or self.getProcessPID(self.encoder_executable):
            _profiles.append(__LS__(30038))
        else:
            for _profile in ['p1_', 'p2_', 'p3_', 'p4_', 'p5_', 'p6_', 'p7_']:
                if __addon__.getSetting(_profile + 'enabled') == 'true':
                    _profiles.append(__addon__.getSetting(_profile + 'profilename'))
            if os.listdir(self.tempfolder) != []: _profiles.append(__LS__(30039))
            if self.chain_interrupted: _profiles.append(__LS__(30062))

        if not _profiles:
            raise self.NoProfileEnabledException()

        _idx = xbmcgui.Dialog().select(__LS__(30010), _profiles)
        if _idx == -1:
            raise self.NoProfileSelectedException()

        self.profile = {}
        for _profile in ['p1_', 'p2_', 'p3_', 'p4_', 'p5_', 'p6_', 'p7_']:
            if __addon__.getSetting(_profile + 'profilename') == _profiles[_idx]:
                self.task = _profiles[_idx]
                self.profile['nice'] = __addon__.getSetting(_profile + 'nice')
                self.profile['resolution'] = MAXWIDTH[int(__addon__.getSetting(_profile + 'resolution'))]
                self.profile['quality'] = QUALITY[int(__addon__.getSetting(_profile + 'quality'))]
                self.profile['mintitlelength'] = int(re.match('\d+', __addon__.getSetting(_profile + 'mintitlelength')).group()) * 60
                self.profile['mode'] = int(__addon__.getSetting(_profile + 'mode'))
                self.profile['foreignaudio'] = ALLTRACKS if __addon__.getSetting(_profile + 'foreignaudio').upper() == 'TRUE' else ''
                self.profile['blackandwhite'] = BW if __addon__.getSetting(_profile + 'blackandwhite').upper() == 'TRUE' else ''
                self.profile['additionalhandbrakeargs'] = __addon__.getSetting(_profile + 'additionalhandbrakeargs')

        if _profiles[_idx] == __LS__(30038):
            _procpid = self.getProcessPID(self.ripper_executable)
            if _procpid:
                self.notifyLog('Killing ripper process with PID %s' % _procpid)
                self.killProcessPID(_procpid)
                self.chain_interrupted = False
                __addon__.setSetting('chain_interrupted', 'false')
            _procpid = self.getProcessPID(self.encoder_executable)
            if _procpid:
                self.notifyLog('Killing encoder process with PID %s' % _procpid)
                self.killProcessPID(_procpid)
            raise self.KillCurrentProcessCalledException()
        if _profiles[_idx] == __LS__(30039):
            self.delTempFolder(force=True)
            raise self.CleanUpTempFolderException()
        if _profiles[_idx] == __LS__(30062):
            self.buildDestFileAndFolder()
            self.copyfile(os.path.join(self.tempfolder, self.src), os.path.join(self.destfolder, self.destfile))
            self.delTempFolder()

            self.chain_interrupted = False
            __addon__.setSetting('chain_interrupted', 'false')

            raise self.AbortedRipCompletedException()

    def notifyLog(self, message, level=xbmc.LOGNOTICE, logging=True):
        if logging:
            xbmc.log('[%s] %s' % (__addonID__, message.encode('utf-8')), level)
            
    # Function to write a traceback report to logfile

    def traceError(self, err, exc_tb):
        while exc_tb:
            tb = traceback.format_tb(exc_tb)
            self.notifyLog('%s' % err, level=xbmc.LOGERROR)
            self.notifyLog('in module: %s' % (sys.argv[0].strip() or '<not defined>'), level=xbmc.LOGERROR)
            self.notifyLog('at line:   %s' % traceback.tb_lineno(exc_tb), level=xbmc.LOGERROR)
            self.notifyLog('in file:   %s' % tb[0].split(",")[0].strip()[6:-1],level=xbmc.LOGERROR)
            exc_tb = exc_tb.tb_next            

    def checkSystemSettings(self):

        if not self.ripper_executable:
            raise self.SystemSettingUndefinedException()
        if not self.encoder_executable:
            raise self.SystemSettingUndefinedException()
        if not self.tempfolder:
            raise self.SystemSettingUndefinedException()
        if not self.basefolder:
            raise self.SystemSettingUndefinedException()

    def getCPUPriority(self):
        if platform.system() == 'Windows':
            return CPU_W[int(self.profile['nice'])]
        else:
            return CPU_L[int(self.profile['nice'])]

    def getProcessPID(self, process):
        if not process: return False
        _syscmd = subprocess.Popen(['pidof', process], stdout=subprocess.PIPE)
        PID = _syscmd.stdout.read().strip()
        return PID if PID > 0 else False

    def killProcessPID(self, pid):
        _syscmd = subprocess.call('kill -9 ' + pid, shell=True)

    def delTempFolder(self, force=False):
        #
        # delete old temp files recursive if there any, but only if there's no previous rip/encode running
        #
        if self.getProcessPID(self.ripper_executable) or self.getProcessPID(self.encoder_executable):
            self.notifyLog('Couldn\'t clearing up folder %s, ripper or encoder active' % self.tempfolder)
            return False
        elif not self.del_tf and not force:
            self.notifyLog('Not allowed clearing up folder %s due settings' % self.tempfolder)
            return False
        else:
            self.notifyLog('Clearing up folder %s' % self.tempfolder)
            try:
                for item in os.walk(self.tempfolder, False):
                    for dir in item[1]:
                        path = os.path.join(item[0], dir)
                        if os.path.islink(path):
                            os.unlink(path)
                        else:
                            os.rmdir(path)
                
                    for file in item[2]:
                        path = os.path.join(item[0], file)
                        os.unlink(path)

                # set interrupted flag to false because there is'nt to continue anymore
                self.chain_interrupted = False
                __addon__.setSetting('chain_interrupted', 'false')

            except Exception, e:
                pass

    def buildDestFileAndFolder(self):
        rips = []
        for ext in self.extensions: rips.extend(glob.glob(os.path.join(self.tempfolder, ext)))
        _fsize = 0
        if len(rips) == 1:
            _fsize = os.path.getsize(rips[0])
            self.src = os.path.basename(rips[0])
        else:
            self.notifyLog('More than one file present. Search for largest file as main movie')
            for rip in rips:
                if os.path.getsize(rip) > _fsize:
                    self.src = os.path.basename(rip)
                    _fsize = os.path.getsize(rip)
            self.notifyLog('Suggest that %s with a size of %s is main movie' % (self.src, fmt_size(_fsize)))
        if _fsize > 0:
            _dest = datetime.datetime.now().strftime('%Y_%m_%d.%H_%M_%S')
            _basename = self.src[:str.rfind(self.src,'.')]
            if 'title' in _basename:
                kb = xbmc.Keyboard('', __LS__(30030))
                kb.doModal()
                if kb.isConfirmed() and kb.getText() != '': _dest = kb.getText()
            elif '_t0' in _basename:
                _dest = _basename[:-4].replace('_', ' ')
            else:
                _dest = _basename.replace('_', ' ')

            self.destfile = _dest + '.mkv'
            if self.subfolder:
                self.destfolder = os.path.join(self.basefolder, _dest)
            else:
                self.destfolder = self.basefolder
            if not os.path.exists(self.destfolder): os.makedirs(self.destfolder)
        else:
            raise self.CouldNotFindValidFilesException()
    
    def pollSubprocess(self, process_exec, process):
        _val = ''
        message = __LS__(30063)
        _m = __LS__(30063)
        percent = 0
        _p = 0
        self.ProgressBG.create('%s - %s' % (__addonname__, __version__), message)
        try:
            _comm = subprocess.Popen(process, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True, universal_newlines=True)
            while not xbmc.abortRequested or not self.Monitor.waitForAbort():
                while  _comm.poll() is None:

                    if xbmc.abortRequested or self.Monitor.abortRequested(): break
                    if percent != _p or message != _m:
                        self.ProgressBG.update(int(percent), '%s - %s' % (__addonname__, __version__), __LS__(30040) % (message, percent))
                        _p = percent
                        _m = message
                        self.notifyLog('%s: %s%% done' % (message, percent), logging=self.logging)

                    data = _comm.stdout.readline().split(':')
                    if 'PRGC' in data[0]:
                        _val = data[1].replace('\n', '').split(',')
                        message = _val[2].replace('"', '')
                    elif 'PRGT' in data[0]:
                        _val = data[1].replace('\n', '').split(',')
                        message = _val[2].replace('"', '')
                    elif 'PRGV' in data[0]:
                        _val = data[1].replace('\n', '').split(',')
                        percent = (int(_val[0]) * 100 / int(_val[2]))
                    elif 'Encoding' in data[0]:
                        message = data[0]
                        _val = data[1].replace('\n', '').split(',')
                        percent = float(re.match('^ [0-9]+(\.[0-9])', _val[1]).group())
                    else:
                        pass

                self.ProgressBG.close()
                break
        except Exception, e:
            pass

        if self.ProgressBG is not None: self.ProgressBG.close()

        self.notifyLog('%s finished with status %s' % (process_exec, _comm.poll()), logging=self.logging)
        return _comm.poll()

    def copyfile(self, source, dest):
        bf_size = 1024 * 1024
        bf_max = os.path.getsize(source) / bf_size
        bf_count = 0
        self.notifyLog('Start copying file to \'%s\'' % dest)
        self.ProgressBG.create('%s - %s' % (__addonname__, __version__), '')
        try:
            with open(source, 'rb') as src, open(dest,'wb') as dst:
                while True:
                    _buffer = src.read(bf_size)
                    if not _buffer: break

                    dst.write(_buffer)
                    percent = int(100 * bf_count / bf_max)
                    self.ProgressBG.update(percent, '%s - %s' % (__addonname__, __version__), __LS__(30040) % (__LS__(30041), percent))
                    bf_count += 1

                self.ProgressBG.close()
                src.close()
                dst.close()
                self.notifyLog('Copying file to \'%s\' finished' % dest)
        except Exception, e:
            pass

    def start(self):

        self.notifyLog('Engage Lounge Ripper')
        self.checkSystemSettings()
        self.getUserProfile()

        if self.profile['mode'] == 0 or self.profile['mode'] == 1:
            #
            # RIP ONLY / RIP AND ENCODE
            #
            self.ripper = '%s "%s" --robot --progress=-stdout mkv --decrypt disc:%s all --minlength=%s "%s"' % \
                          (self.getCPUPriority(),
                          self.ripper_executable,
                          self.driveid,
                          self.profile['mintitlelength'],
                          self.tempfolder)

            self.notifyLog('Ripper command line: %s' % self.ripper)

            # Check if media is present in drive [driveno]
            # raise self.MediaIsNotPresentException if isn't
            try:
                _rv = subprocess.check_output(['blkid', '-c', '/dev/null', '/dev/sr%s' % self.driveid])
            except subprocess.CalledProcessError, e:
                _rv = ''
            if not _rv: raise self.RemovableMediaNotPresentException()

            self.notifyLog('Reported media: %s' % (_rv.strip('\n')))

            _rv = self.pollSubprocess(self.ripper_executable ,self.ripper)
            if _rv == None:
                if self.profile['mode'] == 0:
                    self.chain_interrupted = True
                    __addon__.setSetting('chain_interrupted', 'true')
                raise self.RipEncodeProcessStatesToBGException()
            if _rv != 0:
                raise self.MakemkvExitsNotProperlyException()
            self.buildDestFileAndFolder()
            if self.eject: xbmc.executebuiltin('EjectTray()')

        if self.profile['mode'] == 0:
            #
            # RIP ONLY - WE ARE READY
            #
            self.notifyLog('Encoding of \'%s\' not required in this profile' % self.destfile)
            self.copyfile(os.path.join(self.tempfolder, self.src), os.path.join(self.destfolder, self.destfile))
            self.delTempFolder()
            self.DialogOk.notification(__addonname__, __LS__(30049) % (__addonname__, self.task), __IconOk__)

        if self.profile['mode'] == 1 or self.profile['mode'] == 2:
            #
            # RIP AND ENCODE / ENCODE ONLY
            #
            if self.profile['mode'] == 2:
                #
                # ENCODE ONLY - EXPECT FILE(S) IN TEMPFOLDER, USING LARGEST
                #
                self.buildDestFileAndFolder()

            self.encoder = '%s "%s" -i "%s" -o "%s" -f mkv -d slower -N %s --native-dub -m -Z "High Profile" -s 1 %s %s %s %s %s 2>&1' % \
                           (self.getCPUPriority(),
                           self.encoder_executable,
                           os.path.join(self.tempfolder, self.src),
                           os.path.join(self.destfolder, self.destfile),
                           self.lang3,
                           self.profile['foreignaudio'],
                           self.profile['quality'],
                           self.profile['blackandwhite'],
                           self.profile['resolution'],
                           self.profile['additionalhandbrakeargs'])

            self.notifyLog('Encoder command line: %s' % self.encoder)

            _rv = self.pollSubprocess(self.encoder_executable, self.encoder)
            if _rv == None:
                raise self.RipEncodeProcessStatesToBGException()
            if _rv != 0:
                raise self.HandBrakeCLIExitsNotProperlyException()
            #
            # READY
            #
            self.delTempFolder()
            self.DialogOk.notification(__addonname__, __LS__(30049) % (__addonname__, self.task), __IconOk__)

##############################################################################################################
###                                                                                                        ###
###                                                         MAIN                                           ###
###                                                                                                        ###
##############################################################################################################

Ripper = LoungeRipper()
try:
    Ripper.start()
except Ripper.NoProfileEnabledException:
    ok = Ripper.DialogOk.ok(__addonname__, __LS__(30050))
    Ripper.notifyLog('No profiles enabled', level=xbmc.LOGERROR)
except Ripper.NoProfileSelectedException:
    Ripper.notifyLog('No profile selected, exit %s' % __addonname__)
except Ripper.SystemSettingUndefinedException:
    ok = Ripper.DialogOk.ok(__addonname__, __LS__(30052))
    Ripper.notifyLog('One or more system settings are invalid', level=xbmc.LOGERROR)
except Ripper.CouldNotFindValidFilesException:
    ok = Ripper.DialogOk.ok(__addonname__, __LS__(30056) % Ripper.tempfolder)
    Ripper.notifyLog('Could not find any valid files in %s' % Ripper.tempfolder, level=xbmc.LOGERROR)
except Ripper.RemovableMediaNotPresentException:
    Ripper.notifyLog('Could not detect removable media or media isn\'t present or not readable', level=xbmc.LOGERROR)
    ok = Ripper.DialogOk.ok(__addonname__, __LS__(30057))
except Ripper.MakemkvExitsNotProperlyException:
    ok = Ripper.DialogOk.ok(__addonname__, __LS__(30053))
    Ripper.notifyLog('%s don\'t work as expected, possibly too old, key invalid or another error has occured' % Ripper.ripper_executable, level=xbmc.LOGERROR)
except Ripper.HandBrakeCLIExitsNotProperlyException:
    Ripper.notifyLog('An error occured while encoding with %s' % Ripper.encoder_executable, level=xbmc.LOGERROR)
except Ripper.RipEncodeProcessStatesToBGException:
    Ripper.notifyLog('Rip/Encode processes turns into a background process', level=xbmc.LOGNOTICE)
    Ripper.notifyLog('After this toolchain may be broken and incomplete', level=xbmc.LOGNOTICE)
    Ripper.notifyLog('You can continue processing of toolchain afterwards', level=xbmc.LOGNOTICE)
except Ripper.AbortedRipCompletedException:
    ok = Ripper.DialogOk.ok(__addonname__, __LS__(30058))
    Ripper.notifyLog('A previous incomplete rip was completed', level=xbmc.LOGNOTICE)
except Ripper.KillCurrentProcessCalledException:
    Ripper.notifyLog('All current ripper and encoders terminated', level=xbmc.LOGNOTICE)
except Ripper.CleanUpTempFolderException:
    ok = Ripper.DialogOk.ok(__addonname__, __LS__(30046) % Ripper.tempfolder)
    Ripper.notifyLog('Temporary folder %s cleaned' % Ripper.tempfolder, level=xbmc.LOGNOTICE)
except Exception, e:
    Ripper.traceError(e, sys.exc_traceback)
del Ripper
