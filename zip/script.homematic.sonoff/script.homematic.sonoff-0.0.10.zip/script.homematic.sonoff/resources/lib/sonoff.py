#!/usr/bin/python
# -*- coding: utf-8 -*-

import urllib
import socket
import json
import re
import sys

try:
    import tools
except ImportError as e:
    print "module 'tools' not found, redefine..."

    class Tools(object):

        def __init__(self):
            pass

        def writeLog(self, message):
            print(message)


    tools = Tools()

class Sonoff(object):

    TIMEOUT = 3
    SONOFF_CGI = '/cm'
    STATUS = [{'cmnd':'Power Status'}, {'cmnd':'Power2 Status'}, {'cmnd':'Power3 Status'}, {'cmnd':'Power4 Status'}]
    TOGGLE = [{'cmnd':'Power Toggle'}, {'cmnd':'Power2 Toggle'}, {'cmnd':'Power3 Toggle'}, {'cmnd':'Power4 Toggle'}]
    ON = [{'cmnd':'Power On'}, {'cmnd':'Power2 On'}, {'cmnd':'Power3 On'}, {'cmnd':'Power4 On'}]
    OFF = [{'cmnd':'Power Off'}, {'cmnd':'Power2 Off'}, {'cmnd':'Power3 Off'}, {'cmnd':'Power4 Off'}]

    @classmethod
    def select_ip(cls, device):
        return unicode(re.findall(r'[0-9]+(?:\.[0-9]+){3}', device)[0])

    def send(self, device, command, channel='1', timeout=TIMEOUT):
        device = self.select_ip(device)
        try:
            socket.setdefaulttimeout(timeout)
            req = urllib.urlopen('http://%s%s' % (device, self.SONOFF_CGI), urllib.urlencode(command)).read()
            response = req.splitlines()
            result = json.loads(response[0])
            return result.get('POWER', result.get('POWER%s' % (channel), u'UNDEFINED')).upper()
        except IOError as e:
            tools.writeLog('Error: %s' % str(e))
        except Exception as e:
            tools.writeLog('Exception: %s' % str(e))

        return u'UNREACHABLE'


if __name__ == '__main__':
    sd = Sonoff()
    try:
        if sys.argv[2].upper() == 'STATUS':
            tools.writeLog(str(sd.send(sys.argv[1], sd.STATUS[int(sys.argv[3])])))
        elif sys.argv[2].upper() == 'TOGGLE':
            tools.writeLog(str(sd.send(sys.argv[1], sd.TOGGLE[int(sys.argv[3])])))
        elif sys.argv[2].upper == 'ON':
            tools.writeLog(str(sd.send(sys.argv[1], sd.ON[int(sys.argv[3])])))
        elif sys.argv[2].upper == 'OFF':
            tools.writeLog(str(sd.send(sys.argv[1], sd.OFF[int(sys.argv[3])])))
        else:
            tools.writeLog('unknown command')
    except IndexError:
        tools.writeLog('not all arguments passed, use "sonoff.py <IP> STATUS|TOGGLE|ON|OFF <channel (0-3)>"')
